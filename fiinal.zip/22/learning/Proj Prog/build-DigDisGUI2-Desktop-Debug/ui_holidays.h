/********************************************************************************
** Form generated from reading UI file 'holidays.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOLIDAYS_H
#define UI_HOLIDAYS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_HoliDays
{
public:
    QLabel *label;
    QFrame *line;

    void setupUi(QDialog *HoliDays)
    {
        if (HoliDays->objectName().isEmpty())
            HoliDays->setObjectName(QString::fromUtf8("HoliDays"));
        HoliDays->resize(1200, 1024);
        label = new QLabel(HoliDays);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 600, 1024));
        line = new QFrame(HoliDays);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(600, 0, 3, 1024));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        retranslateUi(HoliDays);

        QMetaObject::connectSlotsByName(HoliDays);
    } // setupUi

    void retranslateUi(QDialog *HoliDays)
    {
        HoliDays->setWindowTitle(QApplication::translate("HoliDays", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class HoliDays: public Ui_HoliDays {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOLIDAYS_H
