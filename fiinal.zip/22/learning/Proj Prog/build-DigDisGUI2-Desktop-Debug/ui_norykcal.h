/********************************************************************************
** Form generated from reading UI file 'norykcal.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NORYKCAL_H
#define UI_NORYKCAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_norykcal
{
public:
    QLabel *labelpic;

    void setupUi(QDialog *norykcal)
    {
        if (norykcal->objectName().isEmpty())
            norykcal->setObjectName(QString::fromUtf8("norykcal"));
        norykcal->resize(1200, 1024);
        labelpic = new QLabel(norykcal);
        labelpic->setObjectName(QString::fromUtf8("labelpic"));
        labelpic->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(norykcal);

        QMetaObject::connectSlotsByName(norykcal);
    } // setupUi

    void retranslateUi(QDialog *norykcal)
    {
        norykcal->setWindowTitle(QApplication::translate("norykcal", "Dialog", 0, QApplication::UnicodeUTF8));
        labelpic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class norykcal: public Ui_norykcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NORYKCAL_H
