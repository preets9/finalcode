/********************************************************************************
** Form generated from reading UI file 'scarcal.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCARCAL_H
#define UI_SCARCAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Scarcal
{
public:
    QLabel *imageLabel;

    void setupUi(QDialog *Scarcal)
    {
        if (Scarcal->objectName().isEmpty())
            Scarcal->setObjectName(QString::fromUtf8("Scarcal"));
        Scarcal->resize(1200, 1024);
        imageLabel = new QLabel(Scarcal);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setGeometry(QRect(0, 0, 1200, 1024));

        retranslateUi(Scarcal);

        QMetaObject::connectSlotsByName(Scarcal);
    } // setupUi

    void retranslateUi(QDialog *Scarcal)
    {
        Scarcal->setWindowTitle(QApplication::translate("Scarcal", "Dialog", 0, QApplication::UnicodeUTF8));
        imageLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Scarcal: public Ui_Scarcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCARCAL_H
