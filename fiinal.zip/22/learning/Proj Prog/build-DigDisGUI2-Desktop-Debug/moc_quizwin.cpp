/****************************************************************************
** Meta object code from reading C++ file 'quizwin.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../DigDisGUI2/quizwin.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quizwin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QuizWin[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,   32,   32,   32, 0x08,
      33,   32,   32,   32, 0x08,
      59,   32,   32,   32, 0x08,
      85,   32,   32,   32, 0x08,
     111,   32,   32,   32, 0x08,
     137,   32,   32,   32, 0x08,
     163,   32,   32,   32, 0x08,
     189,   32,   32,   32, 0x08,
     215,   32,   32,   32, 0x08,
     241,   32,   32,   32, 0x08,
     268,   32,   32,   32, 0x08,
     295,   32,   32,   32, 0x08,
     322,   32,   32,   32, 0x08,
     349,   32,   32,   32, 0x08,
     376,   32,   32,   32, 0x08,
     403,   32,   32,   32, 0x08,
     430,   32,   32,   32, 0x08,
     457,   32,   32,   32, 0x08,
     484,   32,   32,   32, 0x08,
     511,   32,   32,   32, 0x08,
     538,   32,   32,   32, 0x08,
     565,   32,   32,   32, 0x08,
     592,   32,   32,   32, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_QuizWin[] = {
    "QuizWin\0on_pushButton_clicked()\0\0"
    "on_pushButton_2_clicked()\0"
    "on_pushButton_3_clicked()\0"
    "on_pushButton_4_clicked()\0"
    "on_pushButton_5_clicked()\0"
    "on_pushButton_6_clicked()\0"
    "on_pushButton_7_clicked()\0"
    "on_pushButton_8_clicked()\0"
    "on_pushButton_9_clicked()\0"
    "on_pushButton_10_clicked()\0"
    "on_pushButton_11_clicked()\0"
    "on_pushButton_12_clicked()\0"
    "on_pushButton_13_clicked()\0"
    "on_pushButton_16_clicked()\0"
    "on_pushButton_17_clicked()\0"
    "on_pushButton_18_clicked()\0"
    "on_pushButton_19_clicked()\0"
    "on_pushButton_20_clicked()\0"
    "on_pushButton_21_clicked()\0"
    "on_pushButton_22_clicked()\0"
    "on_pushButton_14_clicked()\0"
    "on_pushButton_15_clicked()\0"
    "on_pushButton_23_clicked()\0"
};

void QuizWin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        QuizWin *_t = static_cast<QuizWin *>(_o);
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->on_pushButton_3_clicked(); break;
        case 3: _t->on_pushButton_4_clicked(); break;
        case 4: _t->on_pushButton_5_clicked(); break;
        case 5: _t->on_pushButton_6_clicked(); break;
        case 6: _t->on_pushButton_7_clicked(); break;
        case 7: _t->on_pushButton_8_clicked(); break;
        case 8: _t->on_pushButton_9_clicked(); break;
        case 9: _t->on_pushButton_10_clicked(); break;
        case 10: _t->on_pushButton_11_clicked(); break;
        case 11: _t->on_pushButton_12_clicked(); break;
        case 12: _t->on_pushButton_13_clicked(); break;
        case 13: _t->on_pushButton_16_clicked(); break;
        case 14: _t->on_pushButton_17_clicked(); break;
        case 15: _t->on_pushButton_18_clicked(); break;
        case 16: _t->on_pushButton_19_clicked(); break;
        case 17: _t->on_pushButton_20_clicked(); break;
        case 18: _t->on_pushButton_21_clicked(); break;
        case 19: _t->on_pushButton_22_clicked(); break;
        case 20: _t->on_pushButton_14_clicked(); break;
        case 21: _t->on_pushButton_15_clicked(); break;
        case 22: _t->on_pushButton_23_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData QuizWin::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject QuizWin::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_QuizWin,
      qt_meta_data_QuizWin, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QuizWin::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QuizWin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QuizWin::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QuizWin))
        return static_cast<void*>(const_cast< QuizWin*>(this));
    return QDialog::qt_metacast(_clname);
}

int QuizWin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
