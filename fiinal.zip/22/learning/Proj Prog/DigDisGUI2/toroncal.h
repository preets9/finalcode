#ifndef TORONCAL_H
#define TORONCAL_H

#include <QDialog>
#include <QScrollArea>

namespace Ui {
class toroncal;
}

class toroncal : public QDialog
{
    Q_OBJECT

public:
    explicit toroncal(QWidget *parent = nullptr);
    ~toroncal();

private:
    Ui::toroncal *ui;
    QScrollArea *scrollArea;

};

#endif // TORONCAL_H
