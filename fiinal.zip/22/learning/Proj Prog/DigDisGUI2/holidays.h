#ifndef HOLIDAYS_H
#define HOLIDAYS_H

#include <QDialog>

namespace Ui {
class HoliDays;
}

class HoliDays : public QDialog
{
    Q_OBJECT

public:
    explicit HoliDays(QWidget *parent = nullptr);
    ~HoliDays();

private:
    Ui::HoliDays *ui;
};

#endif // HOLIDAYS_H
