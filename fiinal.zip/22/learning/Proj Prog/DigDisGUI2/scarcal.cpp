#include "scarcal.h"
#include "ui_scarcal.h"
#include <QLabel>
#include <QPixmap>

Scarcal::Scarcal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Scarcal)
{
    ui->setupUi(this);
    QPixmap pix("home/pi/Documents/22/learning/peterborough.png");
    ui->imageLabel->setPixmap(pix.scaled(4000,4000,Qt::KeepAspectRatio));
}

Scarcal::~Scarcal()
{
    delete ui;
}
