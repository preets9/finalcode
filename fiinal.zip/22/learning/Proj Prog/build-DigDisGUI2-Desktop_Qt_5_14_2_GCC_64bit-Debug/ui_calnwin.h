/********************************************************************************
** Form generated from reading UI file 'calnwin.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALNWIN_H
#define UI_CALNWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_CalnWin
{
public:
    QLabel *label;
    QTextBrowser *textBrowser;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_9;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QPushButton *pushButton_10;

    void setupUi(QDialog *CalnWin)
    {
        if (CalnWin->objectName().isEmpty())
            CalnWin->setObjectName(QString::fromUtf8("CalnWin"));
        CalnWin->resize(600, 1024);
        label = new QLabel(CalnWin);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 10, 501, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Imprint MT Shadow"));
        font.setPointSize(24);
        label->setFont(font);
        textBrowser = new QTextBrowser(CalnWin);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(20, 170, 561, 191));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Imprint MT Shadow"));
        font1.setPointSize(11);
        textBrowser->setFont(font1);
        pushButton_2 = new QPushButton(CalnWin);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(310, 390, 261, 101));
        pushButton_3 = new QPushButton(CalnWin);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(310, 510, 261, 101));
        pushButton_5 = new QPushButton(CalnWin);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(310, 630, 261, 101));
        pushButton_6 = new QPushButton(CalnWin);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(30, 510, 251, 101));
        pushButton_9 = new QPushButton(CalnWin);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(30, 840, 541, 71));
        pushButton = new QPushButton(CalnWin);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 390, 251, 101));
        pushButton_4 = new QPushButton(CalnWin);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(30, 630, 251, 101));
        pushButton_10 = new QPushButton(CalnWin);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(30, 90, 541, 71));

        retranslateUi(CalnWin);

        QMetaObject::connectSlotsByName(CalnWin);
    } // setupUi

    void retranslateUi(QDialog *CalnWin)
    {
        CalnWin->setWindowTitle(QCoreApplication::translate("CalnWin", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("CalnWin", "GARBAGE COLLECTION DAYS", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("CalnWin", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Imprint MT Shadow'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:10px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; background-color:#ffffff;\"><span style=\" font-family:'Roboto','Helvetica Neue','Helvetica','Arial','sans-serif'; font-size:12pt; font-weight:600; color:#009a00; background-color:#ffffff;\">If you live in house with daytime collection, your waste is collected on a specific day of the week based on where you live in the city. Green Bin organics are picked up every week while Blue Bin recycling and garbage are collected on alternating weeks. Below are few cities's garbage collection schedules.</span></p>\n"
"<p align=\"center\" style=\" m"
                        "argin-top:0px; margin-bottom:10px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; background-color:#ffffff;\"><span style=\" font-family:'Roboto','Helvetica Neue','Helvetica','Arial','sans-serif'; font-size:12pt; font-weight:600; color:#009a00; background-color:#ffffff;\">To know the Garbage schedule for exact location, Select the last option. </span></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:10px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; background-color:#ffffff;\"><span style=\" font-family:'Roboto','Helvetica Neue','Helvetica','Arial','sans-serif'; font-size:12pt; font-weight:600; color:#009a00; background-color:#ffffff;\">\302\240</span></p></body></html>", nullptr));
        pushButton_2->setText(QCoreApplication::translate("CalnWin", "BRAMPTON", nullptr));
        pushButton_3->setText(QCoreApplication::translate("CalnWin", "BURLINGTON", nullptr));
        pushButton_5->setText(QCoreApplication::translate("CalnWin", "NORTH YORK", nullptr));
        pushButton_6->setText(QCoreApplication::translate("CalnWin", "PETERBOROUGH", nullptr));
        pushButton_9->setText(QCoreApplication::translate("CalnWin", "LINK TO EXACT LOCATION", nullptr));
        pushButton->setText(QCoreApplication::translate("CalnWin", "TORONTO", nullptr));
        pushButton_4->setText(QCoreApplication::translate("CalnWin", "HALTON", nullptr));
        pushButton_10->setText(QCoreApplication::translate("CalnWin", "COLLECTION HOLIDAYS SCHEDULE", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CalnWin: public Ui_CalnWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALNWIN_H
