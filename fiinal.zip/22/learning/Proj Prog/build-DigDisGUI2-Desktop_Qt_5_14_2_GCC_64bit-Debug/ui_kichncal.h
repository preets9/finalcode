/********************************************************************************
** Form generated from reading UI file 'kichncal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KICHNCAL_H
#define UI_KICHNCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_kichncal
{
public:

    void setupUi(QDialog *kichncal)
    {
        if (kichncal->objectName().isEmpty())
            kichncal->setObjectName(QString::fromUtf8("kichncal"));
        kichncal->resize(400, 300);

        retranslateUi(kichncal);

        QMetaObject::connectSlotsByName(kichncal);
    } // setupUi

    void retranslateUi(QDialog *kichncal)
    {
        kichncal->setWindowTitle(QCoreApplication::translate("kichncal", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class kichncal: public Ui_kichncal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KICHNCAL_H
