/********************************************************************************
** Form generated from reading UI file 'bramcal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BRAMCAL_H
#define UI_BRAMCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Bramcal
{
public:
    QLabel *label;

    void setupUi(QDialog *Bramcal)
    {
        if (Bramcal->objectName().isEmpty())
            Bramcal->setObjectName(QString::fromUtf8("Bramcal"));
        Bramcal->resize(2048, 1200);
        label = new QLabel(Bramcal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 2048, 1200));

        retranslateUi(Bramcal);

        QMetaObject::connectSlotsByName(Bramcal);
    } // setupUi

    void retranslateUi(QDialog *Bramcal)
    {
        Bramcal->setWindowTitle(QCoreApplication::translate("Bramcal", "Dialog", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Bramcal: public Ui_Bramcal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BRAMCAL_H
